import Fastify from 'fastify';
import cors from '@fastify/cors';
import cookie from '@fastify/cookie';
import { env } from './config/env.js';
import { prismaPlugin, prisma } from './plugins/prisma.js';
import { authRoutes } from './modules/auth/routes.js';

export async function buildApp() {
  const app = Fastify({ logger: true, trustProxy: env.trustProxy });

  await app.register(cors, {
    origin: env.corsOrigins,
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
  });
  await app.register(cookie);
  await app.register(prismaPlugin);

  app.setErrorHandler((err: any, _req, reply) => {
    if (err.validation) {
      return reply.code(400).send({ error: 'Dados inválidos. Verifique os campos e tente novamente.' });
    }
    app.log.error(err);
    const status: number = err.statusCode && err.statusCode < 500 ? err.statusCode : 500;
    return reply.code(status).send({ error: status === 500 ? 'Erro interno do servidor' : err.message });
  });

  app.get('/health', async () => ({ status: 'ok', service: 'manga-api', time: new Date().toISOString() }));

  app.get('/health/db', async (_req, reply) => {
    try {
      await prisma.$queryRaw`SELECT 1`;
      return { status: 'ok', db: 'connected' };
    } catch (err) {
      app.log.error(err);
      return reply.code(500).send({ status: 'error', db: 'disconnected' });
    }
  });

  await app.register(authRoutes, { prefix: '/auth' });

  return app;
}
