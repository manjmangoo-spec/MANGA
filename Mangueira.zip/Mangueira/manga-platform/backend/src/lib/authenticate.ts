import type { FastifyReply, FastifyRequest } from 'fastify';
import { verifyAccess, type AccessPayload } from './jwt.js';

declare module 'fastify' {
  interface FastifyRequest {
    auth?: AccessPayload;
  }
}

/**
 * preHandler de autenticação (Bearer access token).
 * Antes era um `app.decorate` dentro de um plugin encapsulado: as rotas não o enxergavam
 * e GET /auth/me respondia 500. Agora é uma função importável por qualquer módulo (Etapas 2+).
 */
export async function authenticate(req: FastifyRequest, reply: FastifyReply) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) {
    return reply.code(401).send({ error: 'Token ausente' });
  }
  try {
    req.auth = verifyAccess(header.slice(7));
  } catch {
    return reply.code(401).send({ error: 'Token inválido ou expirado' });
  }
}
