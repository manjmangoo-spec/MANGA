import jwt from 'jsonwebtoken';
import { env } from '../config/env.js';

export type AccessPayload = { sub: string; username: string };
export type RefreshPayload = { sub: string; tokenVersion: number; remember: boolean };

export function signAccess(payload: AccessPayload) {
  return jwt.sign(payload, env.jwtAccessSecret, { expiresIn: env.jwtAccessExpires } as any);
}

export function signRefresh(payload: RefreshPayload) {
  return jwt.sign(payload, env.jwtRefreshSecret, { expiresIn: env.jwtRefreshExpires } as any);
}

export function verifyAccess(token: string): AccessPayload {
  return jwt.verify(token, env.jwtAccessSecret) as unknown as AccessPayload;
}

export function verifyRefresh(token: string): RefreshPayload {
  return jwt.verify(token, env.jwtRefreshSecret) as unknown as RefreshPayload;
}
