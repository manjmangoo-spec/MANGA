import type { FastifyInstance, FastifyReply } from 'fastify';
import type { User } from '@prisma/client';
import { env } from '../../config/env.js';
import { prisma } from '../../plugins/prisma.js';
import { authenticate } from '../../lib/authenticate.js';
import { hashPassword, verifyPassword } from '../../lib/password.js';
import { signAccess, signRefresh, verifyRefresh } from '../../lib/jwt.js';
import { registerSchema, loginSchema } from './schemas.js';

const USERNAME_RE = /^[a-z0-9_.]{3,30}$/;
const AVATAR_RE = /^(data:image\/(png|jpe?g|webp|gif);base64,[A-Za-z0-9+/=]+|https:\/\/\S+)$/;

type RegisterBody = { username: string; email: string; password: string; displayName?: string; avatarUrl?: string; remember?: boolean };
type LoginBody = { email: string; password: string; remember?: boolean };

export function publicUser(u: User) {
  return {
    id: u.id,
    username: u.username,
    email: u.email,
    displayName: u.displayName,
    avatarUrl: u.avatarUrl,
    status: u.status,
    createdAt: u.createdAt,
  };
}

const cookieBase = {
  httpOnly: true,
  sameSite: env.cookieSameSite,
  secure: env.cookieSecure,
  path: '/auth',
  domain: env.cookieDomain,
} as const;

/** Emite a sessão: access token (memória do front) + refresh token em cookie httpOnly compartilhado. */
function issueSession(reply: FastifyReply, user: User, remember: boolean) {
  const accessToken = signAccess({ sub: user.id, username: user.username });
  const refresh = signRefresh({ sub: user.id, tokenVersion: 0, remember });
  // remember=false => cookie de sessão (some ao fechar o navegador); vale para Loja e Comunidade.
  reply.setCookie(env.cookieName, refresh, remember ? { ...cookieBase, maxAge: env.refreshMaxAgeSec } : { ...cookieBase });
  return { user: publicUser(user), accessToken };
}

export async function authRoutes(app: FastifyInstance) {
  app.post('/register', { schema: registerSchema }, async (req, reply) => {
    const body = req.body as RegisterBody;
    const username = body.username.trim().replace(/^@+/, '').toLowerCase();
    const email = body.email.trim().toLowerCase();
    const displayName = body.displayName?.trim() || undefined;
    const avatarUrl = body.avatarUrl || undefined;

    if (!USERNAME_RE.test(username)) {
      return reply.code(400).send({ error: 'Usuário inválido: use 3 a 30 letras, números, "_" ou "."' });
    }
    if (avatarUrl && !AVATAR_RE.test(avatarUrl)) {
      return reply.code(400).send({ error: 'Avatar inválido' });
    }

    const exists = await prisma.user.findFirst({ where: { OR: [{ email }, { username }] } });
    if (exists) return reply.code(409).send({ error: 'E-mail ou usuário já em uso' });

    let user: User;
    try {
      user = await prisma.user.create({
        data: { username, email, passwordHash: await hashPassword(body.password), displayName, avatarUrl },
      });
    } catch (err: any) {
      if (err?.code === 'P2002') return reply.code(409).send({ error: 'E-mail ou usuário já em uso' });
      throw err;
    }
    return reply.code(201).send(issueSession(reply, user, body.remember ?? true));
  });

  app.post('/login', { schema: loginSchema }, async (req, reply) => {
    const body = req.body as LoginBody;
    const user = await prisma.user.findUnique({ where: { email: body.email.trim().toLowerCase() } });
    // Mesma resposta para "não existe" e "senha errada" (não revela quais e-mails existem).
    if (!user || !(await verifyPassword(user.passwordHash, body.password))) {
      return reply.code(401).send({ error: 'E-mail ou senha incorretos' });
    }
    return issueSession(reply, user, body.remember ?? false);
  });

  // Chamado por QUALQUER um dos sites ao carregar: se o cookie compartilhado é válido, já entra logado.
  app.post('/refresh', async (req, reply) => {
    const token = req.cookies?.[env.cookieName];
    if (!token) return reply.code(401).send({ error: 'Sem sessão' });
    try {
      const payload = verifyRefresh(token);
      const user = await prisma.user.findUnique({ where: { id: payload.sub } });
      if (!user) return reply.code(401).send({ error: 'Usuário não existe' });
      return issueSession(reply, user, payload.remember ?? false);
    } catch {
      return reply.code(401).send({ error: 'Sessão inválida ou expirada' });
    }
  });

  app.get('/me', { preHandler: authenticate }, async (req, reply) => {
    const user = await prisma.user.findUnique({ where: { id: req.auth!.sub } });
    if (!user) return reply.code(404).send({ error: 'Usuário não encontrado' });
    return { user: publicUser(user) };
  });

  app.post('/logout', async (_req, reply) => {
    // Apagar o cookie compartilhado desloga Loja e Comunidade ao mesmo tempo.
    reply.clearCookie(env.cookieName, { path: '/auth', domain: env.cookieDomain });
    return { ok: true };
  });
}
