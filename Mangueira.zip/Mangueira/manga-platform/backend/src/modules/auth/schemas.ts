export const registerSchema = {
  body: {
    type: 'object',
    required: ['username', 'email', 'password'],
    properties: {
      username: { type: 'string', minLength: 3, maxLength: 31 },
      email: { type: 'string', format: 'email', maxLength: 254 },
      password: { type: 'string', minLength: 6, maxLength: 100 },
      displayName: { type: 'string', maxLength: 60 },
      avatarUrl: { type: 'string', maxLength: 200000 },
      remember: { type: 'boolean' },
    },
  },
} as const;

export const loginSchema = {
  body: {
    type: 'object',
    required: ['email', 'password'],
    properties: {
      email: { type: 'string', format: 'email', maxLength: 254 },
      password: { type: 'string', minLength: 1, maxLength: 100 },
      remember: { type: 'boolean' },
    },
  },
} as const;
