import { PrismaClient } from '@prisma/client';
import type { FastifyInstance } from 'fastify';

export const prisma = new PrismaClient();

export async function prismaPlugin(app: FastifyInstance) {
  await prisma.$connect();
  app.addHook('onClose', async () => {
    await prisma.$disconnect();
  });
}
