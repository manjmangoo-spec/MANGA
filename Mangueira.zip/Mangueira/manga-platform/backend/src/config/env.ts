import 'dotenv/config';

function required(name: string): string {
  const v = process.env[name];
  if (!v) throw new Error(`Variável de ambiente ausente: ${name}`);
  return v;
}

const list = (v?: string) => (v ?? '').split(',').map((s) => s.trim()).filter(Boolean);

/** Converte "15m", "7d", "12h", "30s" em milissegundos. */
function toMs(v: string, fallback: number): number {
  const m = /^(\d+)\s*([smhd])$/.exec(v.trim());
  if (!m) return fallback;
  const unit = { s: 1_000, m: 60_000, h: 3_600_000, d: 86_400_000 }[m[2] as 's' | 'm' | 'h' | 'd'];
  return Number(m[1]) * unit;
}

const nodeEnv = process.env.NODE_ENV ?? 'development';
const isProd = nodeEnv === 'production';

// Origens (Loja + Comunidade) autorizadas a falar com a API usando cookies.
const devOrigins = [
  'http://localhost:5500', 'http://127.0.0.1:5500', // Comunidade
  'http://localhost:5501', 'http://127.0.0.1:5501', // Loja
];
const configuredOrigins = [...list(process.env.CORS_ORIGINS), ...list(process.env.FRONTEND_URL)];
const corsOrigins = [...new Set(configuredOrigins.length ? configuredOrigins : devOrigins)];

const sameSite = (process.env.COOKIE_SAMESITE ?? 'lax').toLowerCase() as 'lax' | 'strict' | 'none';
const jwtRefreshExpires = process.env.JWT_REFRESH_EXPIRES ?? '7d';

export const env = {
  nodeEnv,
  isProd,
  port: Number(process.env.PORT ?? 3333),
  databaseUrl: required('DATABASE_URL'),
  corsOrigins,
  jwtAccessSecret: required('JWT_ACCESS_SECRET'),
  jwtRefreshSecret: required('JWT_REFRESH_SECRET'),
  jwtAccessExpires: process.env.JWT_ACCESS_EXPIRES ?? '15m',
  jwtRefreshExpires,
  // Cookie de sessão COMPARTILHADO entre Loja e Comunidade (emitido pela API).
  cookieName: process.env.COOKIE_NAME ?? 'manga_session',
  // Em produção use o domínio pai (ex.: ".minhaloja.com") para o cookie valer nos dois subdomínios.
  cookieDomain: process.env.COOKIE_DOMAIN || undefined,
  cookieSameSite: sameSite,
  // SameSite=None exige Secure.
  cookieSecure: process.env.COOKIE_SECURE ? process.env.COOKIE_SECURE === 'true' : isProd || sameSite === 'none',
  refreshMaxAgeSec: Math.floor(toMs(jwtRefreshExpires, 7 * 86_400_000) / 1000),
  trustProxy: process.env.TRUST_PROXY === 'true',
};
