import { randomUUID } from 'node:crypto';
import { Server } from 'socket.io';
import { buildApp } from './app.js';
import { env } from './config/env.js';
import { verifyAccess } from './lib/jwt.js';

type ChatUser = { id: string; username: string };
type Ack = (r: { ok: boolean; error?: string }) => void;

async function main() {
  const app = await buildApp();

  // Socket.IO é anexado ANTES do listen (ordem correta com o Fastify).
  const io = new Server(app.server, {
    cors: { origin: env.corsOrigins, methods: ['GET', 'POST'], credentials: true },
  });
  app.addHook('onClose', async () => {
    io.close();
  });

  // Só entra no chat quem tem um access token válido (o mesmo emitido para Loja e Comunidade).
  io.use((socket, next) => {
    try {
      const token = socket.handshake.auth?.token;
      if (typeof token !== 'string') throw new Error('sem token');
      const p = verifyAccess(token);
      socket.data.user = { id: p.sub, username: p.username } as ChatUser;
      next();
    } catch {
      next(new Error('unauthorized'));
    }
  });

  const broadcastPresence = () => {
    const ids = new Set<string>();
    for (const s of io.sockets.sockets.values()) ids.add((s.data.user as ChatUser).id);
    io.emit('presence', { online: ids.size });
  };

  io.on('connection', (socket) => {
    const user = socket.data.user as ChatUser;
    app.log.info(`chat: @${user.username} conectado (${socket.id})`);
    broadcastPresence();

    let windowStart = Date.now();
    let sent = 0;

    socket.on('send_message', (payload: unknown, ack?: Ack) => {
      const reply = typeof ack === 'function' ? ack : () => {};
      const now = Date.now();
      if (now - windowStart > 5_000) { windowStart = now; sent = 0; }
      if (++sent > 6) return reply({ ok: false, error: 'Calma! Você está enviando mensagens rápido demais.' });

      const raw = typeof payload === 'string' ? payload : (payload as { text?: unknown } | null)?.text;
      const text = typeof raw === 'string' ? raw.trim() : '';
      if (!text) return reply({ ok: false, error: 'Mensagem vazia' });
      if (text.length > 2000) return reply({ ok: false, error: 'Mensagem muito longa (máx. 2000)' });

      // O autor vem do TOKEN, nunca do cliente (evita se passar por outro usuário).
      io.emit('receive_message', {
        id: randomUUID(),
        text,
        user: user.username,
        userId: user.id,
        createdAt: new Date().toISOString(),
      });
      reply({ ok: true });
    });

    socket.on('disconnect', () => broadcastPresence());
  });

  try {
    await app.listen({ port: env.port, host: '0.0.0.0' });
  } catch (err) {
    app.log.error(err);
    process.exit(1);
  }
}

main();
