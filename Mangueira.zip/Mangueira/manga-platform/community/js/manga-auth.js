/*!
 * MANGA AUTH — cliente de sessão COMPARTILHADO entre a Manga Store e a Manga Community.
 * Este arquivo é IDÊNTICO nos dois sites (store/js/manga-auth.js e community/js/manga-auth.js).
 *
 * Como funciona o login único:
 *   - Ambos os sites falam com a MESMA API e o MESMO banco de usuários.
 *   - A API grava um cookie httpOnly de sessão (manga_session). Ao abrir qualquer um dos sites,
 *     este script chama POST /auth/refresh: se o cookie existir, o usuário já entra logado
 *     e recebe um access token (guardado só em memória).
 *   - Logout apaga o cookie => desloga nos dois sites.
 *
 * Configuração opcional (defina ANTES de carregar este arquivo):
 *   window.MANGA_CONFIG = { apiUrl: 'https://api.meusite.com', storeUrl: '...', communityUrl: '...' }
 */
(function (global) {
  'use strict';

  var cfg = global.MANGA_CONFIG || {};
  var isLocal = ['localhost', '127.0.0.1', '[::1]'].indexOf(location.hostname) !== -1;
  var API_URL = String(cfg.apiUrl || (isLocal ? location.protocol + '//' + location.hostname + ':3333' : '')).replace(/\/+$/, '');

  var accessToken = null;
  var user = null;
  var refreshing = null;
  var lastCheck = 0;
  var listeners = [];
  var channel = null;
  try { channel = 'BroadcastChannel' in global ? new BroadcastChannel('manga-auth') : null; } catch (_) { channel = null; }

  function snapshot(u) { return u ? [u.id, u.username, u.displayName, u.avatarUrl].join('|') : ''; }

  function setSession(nextUser, token) {
    var changed = snapshot(nextUser) !== snapshot(user);
    user = nextUser || null;
    accessToken = token || null;
    if (changed) listeners.slice().forEach(function (fn) { try { fn(user); } catch (e) { console.error(e); } });
  }

  function notifyOtherTabs() { try { channel && channel.postMessage('changed'); } catch (_) { /* ignore */ } }

  function toError(res, data) {
    var err = new Error((data && (data.error || data.message)) || 'Erro na requisição (' + res.status + ')');
    err.status = res.status;
    return err;
  }

  async function rawFetch(path, opts) {
    try {
      return await fetch(API_URL + path, opts);
    } catch (_) {
      var err = new Error('Não foi possível conectar ao servidor. Verifique sua conexão e se a API está online.');
      err.network = true;
      throw err;
    }
  }

  /** Chama a API já com o access token; se expirar, renova a sessão e repete UMA vez. */
  async function api(path, options) {
    options = options || {};
    var retry = options.retry !== false;
    var headers = {};
    // Fastify rejeita Content-Type JSON com corpo vazio (ex.: POST /auth/logout), então só enviamos com corpo.
    if (options.body) headers['Content-Type'] = 'application/json';
    if (accessToken) headers.Authorization = 'Bearer ' + accessToken;
    var res = await rawFetch(path, {
      method: options.method || 'GET',
      headers: headers,
      credentials: 'include',
      body: options.body ? JSON.stringify(options.body) : undefined
    });
    if (res.status === 401 && retry && options.auth !== false) {
      var ok = await refreshSession();
      if (ok) return api(path, { method: options.method, body: options.body, retry: false });
    }
    var data = await res.json().catch(function () { return {}; });
    if (!res.ok) throw toError(res, data);
    return data;
  }

  /** Verifica o cookie compartilhado. Retorna o usuário logado ou null. */
  function refreshSession() {
    if (refreshing) return refreshing;
    refreshing = (async function () {
      try {
        var res = await rawFetch('/auth/refresh', { method: 'POST', credentials: 'include' });
        if (res.status === 401) { setSession(null, null); return null; }
        if (!res.ok) return user;
        var data = await res.json();
        setSession(data.user, data.accessToken);
        return data.user;
      } catch (_) {
        return user; // API fora do ar: mantém o estado atual
      } finally {
        lastCheck = Date.now();
        refreshing = null;
      }
    })();
    return refreshing;
  }

  async function login(email, password, remember) {
    var data = await api('/auth/login', { method: 'POST', body: { email: email, password: password, remember: !!remember }, auth: false });
    setSession(data.user, data.accessToken);
    notifyOtherTabs();
    return data.user;
  }

  async function register(fields) {
    var data = await api('/auth/register', { method: 'POST', body: fields, auth: false });
    setSession(data.user, data.accessToken);
    notifyOtherTabs();
    return data.user;
  }

  async function logout() {
    try { await api('/auth/logout', { method: 'POST', auth: false }); } catch (_) { /* limpa localmente mesmo assim */ }
    setSession(null, null);
    notifyOtherTabs();
  }

  /** Inicializa: confere o cookie compartilhado e mantém a sessão sincronizada. */
  async function init() {
    var u = await refreshSession();
    // Ao voltar para a aba/janela (ex.: depois de logar no OUTRO site), sincroniza na hora.
    function recheck() { if (!document.hidden && Date.now() - lastCheck > 1500) refreshSession(); }
    document.addEventListener('visibilitychange', recheck);
    global.addEventListener('focus', recheck);
    if (channel) channel.onmessage = function () { refreshSession(); };
    return u;
  }

  function onChange(fn) {
    listeners.push(fn);
    return function () { listeners = listeners.filter(function (f) { return f !== fn; }); };
  }

  /** Reduz a imagem escolhida para um avatar 128x128 (data URL leve) antes de enviar à API. */
  function fileToAvatar(file) {
    return new Promise(function (resolve, reject) {
      if (!file || !/^image\/(png|jpe?g|webp|gif)$/.test(file.type)) return reject(new Error('Escolha uma imagem PNG, JPG, WEBP ou GIF.'));
      if (file.size > 8 * 1024 * 1024) return reject(new Error('A imagem deve ter no máximo 8 MB.'));
      var url = URL.createObjectURL(file);
      var img = new Image();
      img.onload = function () {
        var size = 128, canvas = document.createElement('canvas');
        canvas.width = canvas.height = size;
        var ctx = canvas.getContext('2d');
        var side = Math.min(img.width, img.height);
        ctx.drawImage(img, (img.width - side) / 2, (img.height - side) / 2, side, side, 0, 0, size, size);
        URL.revokeObjectURL(url);
        resolve(canvas.toDataURL('image/jpeg', 0.85));
      };
      img.onerror = function () { URL.revokeObjectURL(url); reject(new Error('Não foi possível ler a imagem.')); };
      img.src = url;
    });
  }

  /** Avatar padrão (iniciais) gerado localmente, sem serviços externos. */
  function initialsAvatar(name) {
    var letter = (String(name || '?').trim()[0] || '?').toUpperCase().replace(/[<>&"']/g, '?');
    var svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#8a2be2"/><stop offset="1" stop-color="#b54aff"/></linearGradient></defs><rect width="96" height="96" fill="url(#g)"/><text x="48" y="48" dy=".35em" text-anchor="middle" font-family="Montserrat,Arial,sans-serif" font-size="46" font-weight="800" fill="#fff">' + letter + '</text></svg>';
    return 'data:image/svg+xml,' + encodeURIComponent(svg);
  }

  global.MangaAuth = {
    init: init,
    login: login,
    register: register,
    logout: logout,
    refreshSession: refreshSession,
    api: api,
    onChange: onChange,
    getUser: function () { return user; },
    getToken: function () { return accessToken; },
    apiUrl: API_URL,
    fileToAvatar: fileToAvatar,
    initialsAvatar: initialsAvatar
  };
})(window);
