(() => {
  'use strict';

  const Auth = window.MangaAuth;
  const CFG = window.MANGA_CONFIG || {};
  const $ = (id) => document.getElementById(id);
  const prefersReduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  const isTouch = window.matchMedia('(pointer: coarse)').matches;

  /* ================= LINKS PARA A LOJA ================= */
  $('siteSwitch').href = CFG.storeUrl || '/';
  $('accountStore').href = CFG.storeUrl || '/';
  $('navStore').href = CFG.storeUrl || '/';

  /* ================= CURSOR ================= */
  const cursorDot = document.querySelector('.cursor-dot');
  const cursorOutline = document.querySelector('.cursor-outline');

  if (cursorDot && cursorOutline && !isTouch) {
    let mouseX = 0, mouseY = 0, outlineX = 0, outlineY = 0;
    document.addEventListener('mousemove', (e) => {
      mouseX = e.clientX; mouseY = e.clientY;
      cursorDot.style.left = mouseX + 'px';
      cursorDot.style.top = mouseY + 'px';
    });
    const animateOutline = () => {
      outlineX += (mouseX - outlineX) * 0.18;
      outlineY += (mouseY - outlineY) * 0.18;
      cursorOutline.style.left = outlineX + 'px';
      cursorOutline.style.top = outlineY + 'px';
      requestAnimationFrame(animateOutline);
    };
    animateOutline();

    // Delegação: vale também para mensagens, menus e modais criados depois.
    const HOVER = 'a, button, input, label, .room-card, .post-card';
    document.addEventListener('mouseover', (e) => { if (e.target.closest?.(HOVER)) cursorOutline.classList.add('hover'); });
    document.addEventListener('mouseout', (e) => {
      if (e.target.closest?.(HOVER) && !e.relatedTarget?.closest?.(HOVER)) cursorOutline.classList.remove('hover');
    });
  }

  /* ================= HEADER GLOW ================= */
  const header = $('mainHeader');
  header?.addEventListener('mousemove', (e) => {
    const rect = header.getBoundingClientRect();
    header.style.setProperty('--header-light-x', ((e.clientX - rect.left) / rect.width) * 100 + '%');
  });

  /* ================= ATMOSFERA ================= */
  const ambientLights = document.querySelector('.ambient-lights');
  if (ambientLights && !isTouch && !prefersReduced) {
    document.addEventListener('mousemove', (e) => {
      ambientLights.style.setProperty('--ambient-x', (e.clientX / window.innerWidth - 0.5) * 30 + 'px');
      ambientLights.style.setProperty('--ambient-y', (e.clientY / window.innerHeight - 0.5) * 30 + 'px');
    });
  }

  /* ================= REACTIVE CARDS ================= */
  document.querySelectorAll('.reactive-purple-card').forEach((card) => {
    let reflection = card.querySelector('.card-purple-reflection');
    if (!reflection) {
      reflection = document.createElement('div');
      reflection.className = 'card-purple-reflection';
      card.appendChild(reflection);
    }
    card.addEventListener('mousemove', (e) => {
      const rect = card.getBoundingClientRect();
      card.style.setProperty('--card-light-x', ((e.clientX - rect.left) / rect.width) * 100 + '%');
      card.style.setProperty('--card-light-y', ((e.clientY - rect.top) / rect.height) * 100 + '%');
      reflection.style.opacity = '1';
    });
    card.addEventListener('mouseleave', () => { reflection.style.opacity = '0'; });
  });

  /* ================= TILT 3D ================= */
  const TILT_MAX = 6;
  if (!isTouch && !prefersReduced) {
    document.querySelectorAll('.tilt-card').forEach((card) => {
      card.addEventListener('mousemove', (e) => {
        const rect = card.getBoundingClientRect();
        const px = (e.clientX - rect.left) / rect.width - 0.5;
        const py = (e.clientY - rect.top) / rect.height - 0.5;
        card.style.transform = `perspective(1000px) rotateX(${-py * TILT_MAX * 2}deg) rotateY(${px * TILT_MAX * 2}deg) translateY(-4px)`;
      });
      card.addEventListener('mouseleave', () => { card.style.transform = ''; });
    });
  }

  /* ================= PARTÍCULAS ================= */
  const canvas = document.querySelector('.ambient-particles');
  if (canvas && !prefersReduced) {
    const ctx = canvas.getContext('2d');
    let particles = [], W = 0, H = 0;
    const createParticles = () => {
      const count = Math.min(60, Math.floor((W * H) / 30000));
      particles = Array.from({ length: count }, () => ({
        x: Math.random() * W, y: Math.random() * H, r: Math.random() * 1.8 + 0.4,
        vx: (Math.random() - 0.5) * 0.25, vy: (Math.random() - 0.5) * 0.25, alpha: Math.random() * 0.5 + 0.15,
      }));
    };
    const resize = () => { W = canvas.width = window.innerWidth; H = canvas.height = window.innerHeight; createParticles(); };
    resize();
    window.addEventListener('resize', resize);

    const draw = () => {
      if (!document.hidden) {
        ctx.clearRect(0, 0, W, H);
        ctx.shadowColor = 'rgba(181,74,255,0.8)';
        ctx.shadowBlur = 6;
        particles.forEach((p) => {
          p.x += p.vx; p.y += p.vy;
          if (p.x < 0) p.x = W; else if (p.x > W) p.x = 0;
          if (p.y < 0) p.y = H; else if (p.y > H) p.y = 0;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          ctx.fillStyle = `rgba(181, 74, 255, ${p.alpha})`;
          ctx.fill();
        });
        ctx.shadowBlur = 0;
      }
      requestAnimationFrame(draw);
    };
    draw();
  }

  /* ================= LIKE (demonstração) ================= */
  document.querySelectorAll('.post-action').forEach((btn) => {
    btn.addEventListener('click', () => {
      if (!btn.querySelector('svg path[d*="20.84"]')) return;
      btn.classList.toggle('liked');
      const numText = btn.childNodes[btn.childNodes.length - 1];
      if (numText && numText.nodeType === 3) {
        const n = (parseInt(numText.textContent, 10) || 0) + (btn.classList.contains('liked') ? 1 : -1);
        numText.textContent = ' ' + Math.max(0, n);
      }
    });
  });

  /* ================= SCROLL SUAVE + LINKS "#" ================= */
  document.querySelectorAll('a[href="#"]').forEach((a) => a.addEventListener('click', (e) => e.preventDefault()));
  document.querySelectorAll('.nav-links a[href^="#"]').forEach((link) => {
    link.addEventListener('click', (e) => {
      const target = document.querySelector(link.getAttribute('href'));
      if (!target) return;
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
      document.querySelectorAll('.nav-links a').forEach((l) => l.classList.remove('active'));
      link.classList.add('active');
    });
  });

  $('notifBtn')?.addEventListener('click', () => $('notifBtn').querySelector('.notif-badge')?.remove());

  /* ================= MODAL DE AUTENTICAÇÃO (conta única Loja + Comunidade) ================= */
  const authModal = $('authModal');
  const authModalContent = $('authModalContent');
  const authForm = $('authForm');
  const registerForm = $('registerForm');
  let errorTimer, lastFocus = null;

  function showServerError(id, msg) {
    const el = $(id);
    el.textContent = msg || '';
    el.classList.toggle('show', !!msg);
  }
  function shake() {
    authModalContent.classList.remove('error-mode');
    void authModalContent.offsetWidth;
    authModalContent.classList.add('error-mode');
    clearTimeout(errorTimer);
    errorTimer = setTimeout(() => authModalContent.classList.remove('error-mode'), 3000);
  }
  function clearErrors() {
    authModalContent.classList.remove('error-mode');
    document.querySelectorAll('#authModal .input-group').forEach((g) => g.classList.remove('error'));
    showServerError('authServerError', '');
    showServerError('regServerError', '');
  }
  function showView(view) {
    const login = view === 'login';
    authForm.hidden = !login;
    registerForm.hidden = login;
    $('authTitle').textContent = login ? 'BEM-VINDO À COMUNIDADE' : 'CRIE SUA CONTA';
    $('authSub').textContent = login ? 'Acesse com sua conta Manga' : 'A mesma conta vale na Manga Store';
    clearErrors();
    setTimeout(() => (login ? $('authEmail') : $('regUsername')).focus(), 60);
  }
  function openAuth(view = 'login') {
    lastFocus = document.activeElement;
    showView(view);
    authModal.classList.add('active');
    authModal.setAttribute('aria-hidden', 'false');
    document.body.classList.add('modal-open');
  }
  function closeAuth() {
    authModal.classList.remove('active');
    authModal.setAttribute('aria-hidden', 'true');
    document.body.classList.remove('modal-open');
    clearErrors();
    lastFocus?.focus?.({ preventScroll: true });
  }

  $('closeAuthModal').addEventListener('click', closeAuth);
  authModal.addEventListener('click', (e) => { if (e.target === authModal) closeAuth(); });
  document.addEventListener('keydown', (e) => {
    if (e.key !== 'Escape') return;
    if (authModal.classList.contains('active')) closeAuth();
    toggleMenu(false);
  });
  $('toRegister').addEventListener('click', (e) => { e.preventDefault(); showView('register'); });
  $('toLogin').addEventListener('click', (e) => { e.preventDefault(); showView('login'); });

  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const mark = (groupId, bad) => { $(groupId).classList.toggle('error', bad); return bad; };

  authForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    showServerError('authServerError', '');
    const email = $('authEmail').value.trim();
    const pass = $('authPassword').value;
    const bad = [mark('authEmailGroup', !EMAIL_RE.test(email)), mark('authPasswordGroup', pass.length < 1)].some(Boolean);
    if (bad) { shake(); return; }

    const btn = $('authSubmit');
    btn.disabled = true;
    try {
      await Auth.login(email, pass, $('authRemember').checked);
      authForm.reset();
      closeAuth();
    } catch (err) {
      showServerError('authServerError', err.message);
      shake();
    } finally {
      btn.disabled = false;
    }
  });

  registerForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    showServerError('regServerError', '');
    const username = $('regUsername').value.trim().replace(/^@+/, '');
    const email = $('regEmail').value.trim();
    const password = $('regPassword').value;
    const bad = [
      mark('regUsernameGroup', !/^[A-Za-z0-9_.]{3,30}$/.test(username)),
      mark('regEmailGroup', !EMAIL_RE.test(email)),
      mark('regPasswordGroup', password.length < 6),
    ].some(Boolean);
    if (bad) { shake(); return; }

    const btn = $('regSubmit');
    btn.disabled = true;
    try {
      await Auth.register({ username, email, password, displayName: $('regName').value.trim() || undefined, remember: true });
      registerForm.reset();
      closeAuth();
    } catch (err) {
      showServerError('regServerError', err.message);
      shake();
    } finally {
      btn.disabled = false;
    }
  });

  document.querySelectorAll('#authModal input').forEach((el) => el.addEventListener('input', () => {
    el.closest('.input-group')?.classList.remove('error');
    authModalContent.classList.remove('error-mode');
  }));

  /* ================= PERFIL / MENU DA CONTA ================= */
  const accountMenu = $('accountMenu');
  const profileBtn = $('profileBtn');
  function toggleMenu(force) {
    const open = typeof force === 'boolean' ? force : !accountMenu.classList.contains('open');
    accountMenu.classList.toggle('open', open);
    profileBtn.setAttribute('aria-expanded', String(open));
  }
  profileBtn.addEventListener('click', () => (Auth.getUser() ? toggleMenu() : openAuth('login')));
  document.addEventListener('click', (e) => {
    if (accountMenu.classList.contains('open') && !accountMenu.contains(e.target) && !profileBtn.contains(e.target)) toggleMenu(false);
  });
  $('logoutBtn').addEventListener('click', async () => { toggleMenu(false); await Auth.logout(); });

  /* ================= CHAT EM TEMPO REAL (Socket.IO autenticado) ================= */
  const chatForm = $('chatForm');
  const chatInput = $('chatInput');
  const chatMessages = $('chatMessages');
  const DEMO_HTML = chatMessages.innerHTML;
  const MAX_MESSAGES = 200;
  let socket = null, reauthAt = 0;

  function setStatus(state, text) {
    const el = $('chatStatus');
    el.dataset.state = state;
    el.textContent = text;
  }
  function chatNotice(text) {
    const el = $('chatNotice');
    el.textContent = text;
    clearTimeout(chatNotice.t);
    chatNotice.t = setTimeout(() => { el.textContent = ''; }, 4000);
  }

  function connectChat() {
    if (socket) return;
    if (typeof window.io === 'undefined') { setStatus('offline', 'Chat indisponível'); return; }
    setStatus('connecting', 'Conectando…');
    socket = window.io(Auth.apiUrl || undefined, {
      auth: (cb) => cb({ token: Auth.getToken() }),
      withCredentials: true,
    });
    socket.on('connect', () => setStatus('online', 'Conectado'));
    socket.on('disconnect', () => setStatus('connecting', 'Reconectando…'));
    socket.on('connect_error', async (err) => {
      if (err?.message === 'unauthorized') {
        if (Date.now() - reauthAt < 5000) return setStatus('offline', 'Sessão inválida');
        reauthAt = Date.now();
        const user = await Auth.refreshSession(); // token expirou: renova pela sessão compartilhada
        if (user && socket) socket.connect();
        return;
      }
      setStatus('offline', 'Servidor indisponível');
    });
    socket.on('presence', ({ online }) => { $('chatOnline').textContent = `● ${online} online`; });
    socket.on('receive_message', addMessage);
  }

  function disconnectChat() {
    if (socket) { socket.removeAllListeners(); socket.disconnect(); socket = null; }
    chatMessages.innerHTML = DEMO_HTML;
    $('chatOnline').textContent = '● — online';
    setStatus('offline', 'Entre para conversar');
  }

  function addMessage(data) {
    if (!data || typeof data.user !== 'string' || typeof data.text !== 'string') return;
    const me = Auth.getUser();
    const isMe = !!me && data.userId === me.id;

    const msg = document.createElement('div');
    msg.className = 'chat-msg' + (isMe ? ' me' : '');
    const img = document.createElement('img');
    img.alt = '';
    img.src = isMe && me.avatarUrl ? me.avatarUrl : Auth.initialsAvatar(data.user);
    const box = document.createElement('div');
    const name = document.createElement('strong');
    name.textContent = data.user;
    const p = document.createElement('p');
    p.textContent = data.text; // textContent: nunca interpreta HTML (evita XSS)
    box.append(name, p);
    msg.append(img, box);

    const stick = chatMessages.scrollHeight - chatMessages.scrollTop - chatMessages.clientHeight < 120 || isMe;
    chatMessages.append(msg);
    while (chatMessages.children.length > MAX_MESSAGES) chatMessages.firstElementChild.remove();
    if (stick) chatMessages.scrollTop = chatMessages.scrollHeight;
  }

  chatForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const text = chatInput.value.trim();
    if (!text) return;
    if (!Auth.getUser()) { openAuth('login'); return; }
    if (!socket || !socket.connected) { chatNotice('Você está offline. Aguarde a reconexão com o servidor de chat.'); return; }
    socket.emit('send_message', { text }, (res) => {
      if (res && res.ok) return;
      chatNotice((res && res.error) || 'Não foi possível enviar a mensagem.');
      if (!chatInput.value) chatInput.value = text;
    });
    chatInput.value = '';
  });

  /* ================= HERO / SALAS ================= */
  function goToChat() {
    $('chatPanel').scrollIntoView({ behavior: prefersReduced ? 'auto' : 'smooth', block: 'center' });
    setTimeout(() => chatInput.focus({ preventScroll: true }), 400);
  }
  $('joinBtn').addEventListener('click', () => (Auth.getUser() ? goToChat() : openAuth('register')));
  document.querySelectorAll('.room-enter').forEach((b) => b.addEventListener('click', () => (Auth.getUser() ? goToChat() : openAuth('login'))));

  /* ================= ESTADO DE SESSÃO ================= */
  function render(user) {
    const logged = !!user;
    $('guestChip').hidden = logged;
    $('userProfileHeader').hidden = !logged;
    $('joinLabel').textContent = logged ? 'IR PARA O CHAT' : 'ENTRAR NA COMUNIDADE';
    profileBtn.setAttribute('aria-label', logged ? `Minha conta (@${user.username})` : 'Entrar');
    if (logged) {
      const fallback = Auth.initialsAvatar(user.displayName || user.username);
      const avatar = $('headerAvatar');
      avatar.onerror = () => { avatar.onerror = null; avatar.src = fallback; };
      avatar.src = user.avatarUrl || fallback;
      $('headerUsername').textContent = '@' + user.username;
      $('accountName').textContent = user.displayName || user.username;
      $('accountMail').textContent = user.email;
      closeAuthIfOpen();
      connectChat();
    } else {
      toggleMenu(false);
      disconnectChat();
    }
  }
  function closeAuthIfOpen() { if (authModal.classList.contains('active')) closeAuth(); }

  // Login/logout aqui, na Loja ou em outra aba atualizam a tela na hora.
  Auth.onChange(render);
  Auth.init().then(() => render(Auth.getUser()));
})();
