// Servidor estático de desenvolvimento (zero dependências).
//   Manga Community -> http://localhost:5500
//   Manga Store     -> http://localhost:5501
// Os sites precisam rodar via http:// (e não file://) para o cookie de sessão compartilhado funcionar.
import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { extname, join, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));
const sites = [
  { name: 'Manga Community', dir: 'community', port: 5500 },
  { name: 'Manga Store', dir: 'store', port: 5501 },
];
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml',
  '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon',
};

for (const site of sites) {
  const base = join(root, site.dir);
  http
    .createServer(async (req, res) => {
      try {
        const pathname = decodeURIComponent(new URL(req.url ?? '/', 'http://x').pathname);
        let file = resolve(join(base, pathname));
        if (file !== base && !file.startsWith(base + sep)) { res.writeHead(403).end('Forbidden'); return; }
        if ((await stat(file).catch(() => null))?.isDirectory()) file = join(file, 'index.html');
        const data = await readFile(file);
        res.writeHead(200, { 'Content-Type': types[extname(file).toLowerCase()] ?? 'application/octet-stream', 'Cache-Control': 'no-store' });
        res.end(data);
      } catch {
        res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }).end('Não encontrado');
      }
    })
    .listen(site.port, () => console.log(`${site.name.padEnd(16)} http://localhost:${site.port}`));
}
