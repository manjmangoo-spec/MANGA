# Manga Platform — Loja + Comunidade (login único)

```
backend/     API única (Fastify + Prisma + Socket.IO) — UM banco de usuários para os dois sites
store/       Manga Store      (index.html + js/manga-auth.js)
community/   Manga Community  (index.html, css/, js/app.js + js/manga-auth.js)
scripts/     servidor estático de desenvolvimento
```

## Rodar (dev)

```powershell
cd backend
npm install
npx prisma migrate deploy      # o banco já tem a tabela User; sem mudanças de schema
cd ..
npm run dev:api                # API + chat  -> http://localhost:3333
npm run dev:sites              # Comunidade :5500  |  Loja :5501   (em outro terminal)
```

Abra **http://localhost:5501** (Loja) e **http://localhost:5500** (Comunidade). Use sempre `localhost` (ou sempre `127.0.0.1`) nos dois.

## Como o login é compartilhado
1. Os dois sites usam a mesma API (`/auth/*`) e a mesma tabela `User`.
2. Ao logar/cadastrar, a API grava o cookie httpOnly `manga_session`.
3. `js/manga-auth.js` (idêntico nos dois sites) chama `POST /auth/refresh` ao carregar e ao voltar o foco para a aba: com o cookie válido o usuário já entra logado e recebe o access token (só em memória).
4. Logout apaga o cookie ⇒ desloga nos dois.
5. O chat (Socket.IO) exige esse mesmo token; o autor da mensagem vem do token, não do cliente.

## Produção
- Configure `CORS_ORIGINS` com as URLs reais da Loja e da Comunidade.
- Para o cookie valer nos dois sites, hospede-os sob o mesmo domínio pai (ex.: `loja.site.com`, `comunidade.site.com`, `api.site.com`) e defina `COOKIE_DOMAIN=".site.com"` (HTTPS; `NODE_ENV=production` ativa `Secure`).
- Domínios totalmente diferentes: `COOKIE_SAMESITE=none` (HTTPS) — navegadores com bloqueio de cookies de terceiros podem impedir o login único; prefira subdomínios.
- Em cada site, defina `window.MANGA_CONFIG = { apiUrl, communityUrl / storeUrl }` antes de `js/manga-auth.js` (bloco já presente no topo dos HTML).
- Trocar os segredos `JWT_*` por valores novos e longos.

## Base pronta para a Etapa 2
- `backend/src/lib/authenticate.ts`: `preHandler: authenticate` em qualquer rota nova (`req.auth.sub` = id do usuário).
- `MangaAuth.api('/rota', { method, body })` no front: já envia o token e renova a sessão sozinho.
- `socket.data.user` no servidor de chat já traz `{ id, username }` autenticado.
